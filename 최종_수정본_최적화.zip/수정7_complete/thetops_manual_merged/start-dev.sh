#!/bin/bash
# 실행 스크립트: 터미널에서 sh start-dev.sh로 실행
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
# 의존성 설치 (최초 1회만 수행)
npm install
# 개발 서버 실행
npm run dev
