# thetops Festival Manual

## 실행 방법

1. 프로젝트 폴더로 이동:
   ```bash
1. 프로젝트 폴더로 이동:
   ```bash
   cd <프로젝트_폴더_이름>
   ```
   ```

2. 의존성 설치 (legacy-peer-deps 자동 적용):
   ```bash
   npm install
   ```

3. 개발 서버 실행:
   ```bash
   npm run dev
   ```

4. 브라우저에서 접속:
   ```
   http://localhost:3000
   ```

Map 메뉴를 클릭하면 카카오맵이 현재 위치 기반으로 표시됩니다.
