import React, { useState, useEffect, useContext } from 'react';
import { PasswordContext } from './PasswordContext';
import * as XLSX from 'xlsx';
import QRCode from 'qrcode.react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Admin from './pages/Admin';
import Arrival from './pages/Arrival';
import Parking from './pages/Parking';
import Mission from './pages/Mission';
import Map from './pages/Map';
import Coupon from './pages/Coupon';
import Exchange from './pages/Exchange';
import Event from './pages/Event';
import Notice from './pages/Notice';
import Wishlist from './pages/Wishlist';
import LostAndFound from './pages/LostAndFound';
import { Home as HomeIcon, List as ListIcon, RotateCcw as RestartIcon, Lock as LockIcon } from 'lucide-react';

interface Registration {
  id: string;
  name: string;
  phone: string;
  timestamp: string;
}

const App: React.FC = () => {
  const { password, setPassword } = useContext(PasswordContext);
  const handlePasswordClick = () => {
    const newPw = prompt('새 비밀번호를 입력하세요', password);
    if (newPw !== null) {
      setPassword(newPw);
      alert('비밀번호가 변경되었습니다.');
    }
  };
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [match, setMatch] = useState(false);
  const [qrValue, setQrValue] = useState('');
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [excelUsers, setExcelUsers] = useState<{ name: string; phone: string }[]>([]);

  const [adminMode, setAdminMode] = useState(false);
  const [adminTab, setAdminTab] = useState<'메인화면' | '등록자현황' | null>(null);
  const [showPasswordUI, setShowPasswordUI] = useState(false);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem('registrations') || '[]');
    setRegistrations(stored);
  }, []);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/users.xlsx');
      if (!res.ok) {
        alert('users.xlsx 파일을 찾을 수 없습니다.');
        return;
      }
      const data = await res.arrayBuffer();
      const workbook = XLSX.read(data, { type: 'array' });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const users: { 이름: string; 연락처: string }[] = XLSX.utils.sheet_to_json(sheet);
      const found = users.find(u => u.이름 === name && (
      u.연락처.replace(/\D/g, '') === phone.replace(/\D/g, '') ||
      u.연락처.replace(/\D/g, '').endsWith(phone.replace(/\D/g, ''))
      ));
      if (!found) {
        alert('이름 또는 전화번호가 일치하지 않습니다.');
        return;
      }
      setMatch(true);
      const timestamp = new Date().toLocaleString();
      const entry = { id: Date.now().toString(), name, phone, timestamp };
      const updated = [...registrations, entry];
      localStorage.setItem('registrations', JSON.stringify(updated));
      setRegistrations(updated);
      setQrValue(JSON.stringify(entry));
      setTimeout(() => window.print(), 500);
    } catch (err) {
      console.error(err);
      alert('오류가 발생했습니다.');
    }
  };

  const overlayStyle = {
    position: 'fixed' as 'fixed',
    top: 0,
    left: 0,
    width: '2cm',
    height: '2cm',
    zIndex: 1000,
    cursor: 'pointer' as 'pointer'
  };

  // 엑셀 사용자 목록 로드
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/users.xlsx');
        if (!res.ok) return;
        const data = await res.arrayBuffer();
        const wb = XLSX.read(data, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows: any[] = XLSX.utils.sheet_to_json(ws);
        const users = rows.map(u => ({ name: u['이름'], phone: u['연락처'] }));
        setExcelUsers(users as { name: string; phone: string }[]);
      } catch (err) {
        console.error('엑셀 로드 오류:', err);
      }
    })();
  }, []);


  if (!adminMode) {
    return (
      <>
        <div style={overlayStyle} onClick={() => { setAdminMode(true); setAdminTab(null); }} />
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh',
          padding: 20,
        }}>
          <h1>QR 코드 생성기</h1>
          <form onSubmit={handleGenerate} style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}>
            <input
              type="text"
              placeholder="이름"
              value={name}
              onChange={e => setName(e.target.value)}
              required
              autoFocus
              style={{ width: 200, padding: 8, margin: '8px 0', fontSize: 16 }}
            />
            <input
              type="tel"
              placeholder="전화번호"
              inputMode="numeric"
              pattern="[0-9-]*"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              required
              style={{ width: 200, padding: 8, margin: '8px 0', fontSize: 16 }}
            />
            <button type="submit" style={{ padding: '10px 16px', fontSize: 16, cursor: 'pointer' }}>
              생성 및 인쇄
            </button>
          </form>
          {match && (
            <div style={{ marginTop: 20 }}>
              <h2>QR 코드</h2>
              <QRCode value={qrValue} size={256} />
            </div>
          )}
        </div>
      </>
    );
  }

  return (
    <>
    <div style={overlayStyle} onClick={() => setAdminMode(false)} />
    <div style={{ padding: 20 }}>
      {adminTab !== '메인화면' && (
  <div style={{ display: 'flex', gap: 20, justifyContent: 'center', alignItems: 'center', margin: '0 auto' }} >
        <div style={{ textAlign: 'center', cursor: 'pointer' }} onClick={handlePasswordClick}>
          <LockIcon size={48} />
          <div>비밀번호</div>
        </div>
    <div style={{ textAlign: 'center', cursor: 'pointer' }} onClick={() => setAdminMode(false)}>
      <RestartIcon size={48} />
      <div>시작화면</div>
    </div>
    <div style={{ textAlign: 'center', cursor: 'pointer' }} onClick={() => setAdminTab('메인화면')}>
      <HomeIcon size={48} />
      <div>메인화면</div>
    </div>
    <div style={{ textAlign: 'center', cursor: 'pointer' }} onClick={() => setAdminTab('등록자현황')}>
      <ListIcon size={48} />
      <div>등록자현황</div>
    </div>
  </div>
)}
<div style={{ marginTop: 20 }}>
        {adminTab === '메인화면' && (
          <Router>
            <header style={{ display: 'flex', alignItems: 'center', padding: 10, background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
              
              <nav style={{ display: 'flex', gap: '1rem' }}>
                <Link to="/">메인화면</Link>
                <Link to="/arrival">도착</Link>
                <Link to="/parking">주차장안내</Link>
                <Link to="/mission">미션</Link>
                <Link to="/map">지도</Link>
                <Link to="/coupon">쿠폰</Link>
                <Link to="/event">이벤트</Link>
                <Link to="/notice">공지사항</Link>
                <Link to="/lost">분실물</Link>
              </nav>

            </header>
            <main style={{ padding: 20 }}>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/arrival" element={<Arrival />} />
                <Route path="/parking" element={<Parking />} />
                <Route path="/mission" element={<Mission />} />
                <Route path="/map" element={<Map />} />
                <Route path="/coupon" element={<Coupon />} />
                <Route path="/exchange" element={<Exchange />} />
                <Route path="/event" element={<Event />} />
                <Route path="/notice" element={<Notice />} />
                <Route path="/wishlist" element={<Wishlist />} />
                <Route path="/lost" element={<LostAndFound />} />
              </Routes>
            </main>
          </Router>
        )}
        {adminTab === '등록자현황' && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center' }}>
      <h2>등록된 사용자 목록</h2>
      <img src="/images/비밀번호.svg" alt="비밀번호" style={{ width: '24px', height: '24px', cursor: 'pointer', marginLeft: '8px' }} onClick={() => setShowPasswordUI(prev => !prev)} />
    </div>
    <table border={1} cellPadding={5}>
      <thead>
        <tr><th>✅</th><th>이름</th><th>전화번호</th><th>등록시간</th></tr>
      </thead>
      <tbody>
        {excelUsers.map((u, i) => {
          const reg = registrations.find(r => r.name === u.name && (
            u.phone.replace(/\D/g, '') === r.phone.replace(/\D/g, '') ||
            u.phone.replace(/\D/g, '').endsWith(r.phone.replace(/\D/g, ''))
          ));
          return (
            <tr key={i}>
              <td style={{ textAlign: 'center' }}>
                <input type="checkbox" checked={!!reg} readOnly />
              </td>
              <td>{u.name}</td>
              <td>{u.phone}</td>
              <td>{reg ? reg.timestamp : ''}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
          {showPasswordUI && <Admin />} 
          </div>
        )}
      </div>
    </div>
    </>
  );
};

export default App;
