import React from 'react';
export default function Map() {
  return <div><h2>🗺️ Real-time Location Map</h2><div style={{height:200, background:'#ccc'}}>Map Placeholder</div></div>;
}
