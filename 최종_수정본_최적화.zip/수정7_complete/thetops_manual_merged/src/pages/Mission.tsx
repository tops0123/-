import React, { useState } from 'react';
export default function Mission() {
  const list = ['A 부스 방문','B 공연장 인증샷','C 포토존 도장'];
  const [done, setDone] = useState(list.map(()=>false));
  return (
    <div><h2>🎯 Mission Quest</h2>
    <ul>{list.map((m,i)=><li key={i}><label><input type="checkbox" checked={done[i]} onChange={()=>{const d=[...done];d[i]=!d[i];setDone(d);}}/> {m}</label></li>)}</ul>
    </div>
  );
}
