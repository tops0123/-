import React from 'react';
export default function Wishlist() {
  return <h2>⭐ Wishlist</h2>;
}
