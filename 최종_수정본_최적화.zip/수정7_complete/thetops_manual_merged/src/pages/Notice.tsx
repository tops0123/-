import React from 'react';
export default function Notice() {
  return <h2>📢 Notices</h2>;
}
