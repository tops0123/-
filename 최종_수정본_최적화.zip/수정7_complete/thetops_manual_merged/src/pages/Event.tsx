import React from 'react';
export default function Event() {
  return <h2>📅 Event Schedule</h2>;
}
