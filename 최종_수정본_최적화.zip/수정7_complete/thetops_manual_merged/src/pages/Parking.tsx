import React from 'react';
export default function Parking() {
  return (
    <div>
      <h2>🚗 Parking Guidance</h2>
      <p>주요 주차장 위치를 지도에 표시합니다.</p>
      <div style={{height:200, background:'#ddd'}}>Map with parking overlays</div>
    </div>
  );
}
