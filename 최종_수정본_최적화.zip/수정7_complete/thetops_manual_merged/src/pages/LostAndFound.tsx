import React from 'react';
export default function LostAndFound() {
  return <h2>📢 Lost & Found</h2>;
}
