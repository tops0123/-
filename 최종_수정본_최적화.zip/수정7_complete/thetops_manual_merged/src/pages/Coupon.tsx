import React, { useState, useContext } from 'react';
import { PasswordContext } from '../PasswordContext';
import { CheckCircle } from 'lucide-react';

export default function Coupon() {
  const { password } = useContext(PasswordContext);
  const coupons = ['A', 'B'];
  const [used, setUsed] = useState<boolean[]>(coupons.map(() => false));
  const [reqIdx, setReqIdx] = useState<number | null>(null);
  const [pwInput, setPwInput] = useState<string>('');

  const handleUse = (idx: number) => {
    setReqIdx(idx);
  };

  const handleConfirm = () => {
    if (reqIdx !== null && pwInput === password) {
      const newUsed = [...used];
      newUsed[reqIdx] = true;
      setUsed(newUsed);
      setReqIdx(null);
      setPwInput('');
    } else {
      alert('비밀번호가 일치하지 않습니다');
    }
  };

  return (
    <div style={{ textAlign: 'center' }}>
      <h2>🎟️ 자동 쿠폰</h2>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {coupons.map((c, idx) => (
          <li
            key={c}
            style={{ margin: '10px 0', display: 'flex', alignItems: 'center', gap: 10, justifyContent: 'center' }}
          >
            쿠폰 {c}
            {!used[idx] ? (
              <button onClick={() => handleUse(idx)}>사용</button>
            ) : (
              <CheckCircle color="green" size={24} title="사용 완료" />
            )}
          </li>
        ))}
      </ul>
      {reqIdx !== null && (
        <div style={{ marginTop: 20 }}>
          <input
            type="password"
            placeholder="관리자 비밀번호"
            value={pwInput}
            onChange={e => setPwInput(e.target.value)}
            style={{ padding: '8px', marginRight: '10px' }}
          />
          <button onClick={handleConfirm}>확인</button>
          <button onClick={() => setReqIdx(null)} style={{ marginLeft: '10px' }}>
            취소
          </button>
        </div>
      )}
    </div>
);
}
