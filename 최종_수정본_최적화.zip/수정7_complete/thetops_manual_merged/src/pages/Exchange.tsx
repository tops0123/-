import React from 'react';
export default function Exchange() {
  return <h2>🎫 Exchange Voucher</h2>;
}
