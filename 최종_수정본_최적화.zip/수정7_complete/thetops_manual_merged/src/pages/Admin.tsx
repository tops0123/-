import React, { useContext, useState } from 'react';
import { PasswordContext } from '../PasswordContext';

export default function Admin() {
  const { password, setPassword } = useContext(PasswordContext);
  const [input, setInput] = useState('');

  const handleSet = () => {
    if (input.trim()) {
      setPassword(input.trim());
      alert('관리자 비밀번호가 설정되었습니다');
      setInput('');
    } else {
      alert('올바른 비밀번호를 입력해주세요');
    }
  };

  return (
    <div style={{ padding: 20, maxWidth: 400, margin: 'auto' }}>
      <h2>🔐 관리자 모드 - 비밀번호 설정</h2>
      <p>현재 비밀번호: {password ? '********' : '미설정'}</p>
      <input
        type="password"
        placeholder="새 비밀번호 입력"
        value={input}
        onChange={e => setInput(e.target.value)}
        style={{ padding: '8px', width: '100%', marginBottom: 10 }}
      />
      <button onClick={handleSet} style={{ padding: '10px', width: '100%' }}>
        비밀번호 설정
      </button>
    </div>
  );
}
