import React, { useEffect } from 'react';
export default function Arrival() {
  useEffect(() => {
    alert('축제장 도착 10분 전 입니다!');
  }, []);
  return <h2>🔔 Arrival Alert Sent!</h2>;
}
