import React,{useState} from 'react';
import * as XLSX from 'xlsx';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '../firebase';
export default function Register(){
  const [file,setFile]=useState<File|null>(null);
  const handleUpload=async()=>{
    if(!file)return;
    const data=await file.arrayBuffer();
    const wb=XLSX.read(data);
    const ws=wb.Sheets[wb.SheetNames[0]];
    const rows:any[] = XLSX.utils.sheet_to_json(ws);
    for(const row of rows){
      await addDoc(collection(db,'participants'),{name:row.Name,phone:row.Phone,timestamp:new Date()});
    }
    alert('Registered '+rows.length);
  };
  return <div><h2>참가자 등록</h2><input type="file" accept=".xlsx" onChange={e=>setFile(e.target.files?.[0]||null)}/> <button onClick={handleUpload}>엑셀 업로드</button></div>;
}