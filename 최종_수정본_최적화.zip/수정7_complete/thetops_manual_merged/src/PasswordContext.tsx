import React, { createContext, useState } from 'react';

interface PasswordContextType {
  password: string;
  setPassword: (pw: string) => void;
}

export const PasswordContext = createContext<PasswordContextType>({
  password: '',
  setPassword: () => {}
});

export const PasswordProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [password, setPassword] = useState<string>('');
  return (
    <PasswordContext.Provider value={{ password, setPassword }}>
      {children}
    </PasswordContext.Provider>
  );
};
